PETA for Group 7 ICT Software 9 2023-2024 
"Bosco Mobile"

Contributers:
Yash, Bhojwani |
Olivar, Miguel |
Magdato, Lorenzo |
Teo, Zander |

Others:
Galon, Zeev
